# Global Exports of Goods and Services - Data Analysis

A Python analysis of exports of goods and services (as a percentage of GDP) for countries and regions from 1960 to 2023.
The work is in a Jupyter notebook, and the findings are written up in a 14-slide presentation.

Author: Vaishnavi Nanaware
Repository: <https://github.com/vdn1805/Global-export-of-goods-and-services-data-analysis>

## Questions the project answers

- How have exports as a share of GDP changed over the years?
- Which countries export the most relative to their economy?
- How do regions differ?
- How are exports related to time (year)?

## Dataset

The CSV file is not included in this folder. Put it next to the notebook with this name:

```
export_goods_services_countries_dataset.csv
```

| Item | Value |
|---|---|
| Rows | 13,760 |
| Years | 1960 to 2023 (64 years, 215 country/economy codes) |
| Columns | `country_code`, `country_name`, `region`, `sub_region`, `intermediate_region`, `indicator_code`, `indicator_name`, `year`, `exports_of_goods_and_services` |
| Export value | Mean 23.09% of GDP, median 16.56%, min 0%, max 433.84% |
| Missing values | `region`: 5,440 missing. `intermediate_region`: 8,000 missing. All other columns are complete. |

The files do not say where the dataset came from. Add the source here once you confirm it.

## What the notebook does

1. Loads the CSV with Pandas.
2. Prints dataset info and summary statistics.
3. Counts missing values in each column.
4. Fills missing `region` and `intermediate_region` values with `"Unknown"`.
5. Plots the average export share by year (line chart).
6. Finds the top 10 exporting countries in the latest year (2023) and plots them (bar chart).
7. Saves the cleaned data to `cleaned_export_data.csv`.

## Findings

- **Trend:** Exports as a share of GDP rose steadily over the decades, peaked around 2010, then moved up and down, with a drop around 2020.
- **Top exporters in 2023:** Luxembourg, Hong Kong SAR, Singapore, Djibouti, Ireland, Malta, United Arab Emirates, Cyprus, Slovak Republic and Macao SAR. Small economies with large trade sectors lead.
- **Spread:** The distribution is right-skewed. Most countries have low export shares, and a few are very high (above 100%, up to 433.84%).
- **Time relationship:** The correlation between year and export share is 0.37, a moderate positive link.
- **Regions:** Export shares differ by region. Most regions rose from the 1980s onward.

### Charts

![Export trend over time](images/01-export-trend.png)

![Top 10 exporting countries in 2023](images/02-top-10-exporters-2023.png)

![Correlation matrix](images/03-correlation-matrix.png)

![Distribution of export share](images/04-export-distribution.png)

![Average exports by region](images/05-average-exports-by-region.png)

![Boxplot of export share](images/06-export-boxplot.png)

![Export trends by region](images/07-regional-trends.png)

## How to run

Requires Python 3.8 or newer.

```bash
pip install pandas matplotlib seaborn notebook
jupyter notebook export_data_analysis.ipynb
```

Place `export_goods_services_countries_dataset.csv` in the same folder, then choose **Run All**.

## Files

| File | Purpose |
|---|---|
| `export_data_analysis.ipynb` | Analysis notebook (steps 1 to 7 above) |
| `Enhanced_Global_Exports_Presentation.pptx` | 14-slide presentation: problem statement, charts with explanations, conclusion |
| `images/` | Charts taken from the presentation |

## Notes

- The notebook contains the cleaning, the trend chart and the top 10 chart. The correlation matrix, histogram, regional bar chart, boxplot and regional trend chart appear only in the presentation, so their code is not in the notebook yet.
- Country and region names in the data are in Spanish capitals, and some accented letters appear garbled in the charts. Re-save the CSV as UTF-8 or load it with the matching `encoding` option.
- In the regional chart, "Unknown" has the highest average. It groups the 5,440 rows with no region, so read it with that in mind.
- With recent versions of pandas and seaborn, `fillna(..., inplace=True)` on a column and `palette` without `hue` may print warnings.
